import React, { useState, useEffect } from 'react';
import {
  Grid,
  Typography,
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Card,
  CardContent,
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Drawer,
  IconButton,
  Chip,
  Tooltip,
  Skeleton,
  Divider
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import MainCard from 'components/MainCard';
import Breadcrumb from 'routes/Breadcrumb';
import areaEstimationService from './areaEstimationService';

// Icons
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import TableChartIcon from '@mui/icons-material/TableChart';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import CloseIcon from '@mui/icons-material/Close';
import RefreshIcon from '@mui/icons-material/Refresh';
import LayersIcon from '@mui/icons-material/Layers';
import OpacityIcon from '@mui/icons-material/Opacity';
import SpaIcon from '@mui/icons-material/Spa';
import GrainIcon from '@mui/icons-material/Grain';

const DISTRICTS = [
  { id: 'All', name: 'All Districts' },
  { id: 1, name: 'Thiruvananthapuram' },
  { id: 2, name: 'Kollam' },
  { id: 3, name: 'Pathanamthitta' },
  { id: 4, name: 'Alappuzha' },
  { id: 5, name: 'Kottayam' },
  { id: 6, name: 'Idukki' },
  { id: 7, name: 'Ernakulam' },
  { id: 8, name: 'Thrissur' },
  { id: 9, name: 'Palakkad' },
  { id: 10, name: 'Malappuram' },
  { id: 11, name: 'Kozhikode' },
  { id: 12, name: 'Wayanad' },
  { id: 13, name: 'Kannur' },
  { id: 14, name: 'Kasaragod' }
];

const AreaEstimationDashboard = () => {
  const navigate = useNavigate();

  const estimationCategories = [
    {
      id: 'Seasonal Crops',
      title: 'Seasonal Crops',
      desc: 'Autumn, Winter, & Summer crop estimations',
      icon: <SpaIcon sx={{ fontSize: 32 }} />,
      gradient: 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)',
    },
    {
      id: 'Annual & Perennial Crops',
      title: 'Annual & Perennial Crops',
      desc: 'Coconut, Rubber, etc. yearly estimates',
      icon: <GrainIcon sx={{ fontSize: 32 }} />,
      gradient: 'linear-gradient(135deg, #ff9966 0%, #ff5e62 100%)',
    },
    {
      id: 'Land Utilization',
      title: 'Land Utilization',
      desc: 'Forest, Barren, Cultivable lands assessment',
      icon: <LayersIcon sx={{ fontSize: 32 }} />,
      gradient: 'linear-gradient(135deg, #00c6ff 0%, #0072ff 100%)',
    },
    {
      id: 'Irrigation',
      title: 'Irrigation Details',
      desc: 'Canal, Well, & rain-fed source stats',
      icon: <OpacityIcon sx={{ fontSize: 32 }} />,
      gradient: 'linear-gradient(135deg, #8a2387 0%, #e94057 50%, #f27121 100%)',
    }
  ];

  // Filters State
  const [estType, setEstType] = useState('Seasonal Crops');
  const year = '2026';
  const [season, setSeason] = useState('Autumn');
  const district = 'All';

  // Last validation check time
  const [lastValidationTime, setLastValidationTime] = useState(() => {
    return localStorage.getItem(`last_val_time_${estType}_${season}`) || 'Never checked';
  });

  useEffect(() => {
    localStorage.removeItem('earas_form1_submissions');
  }, []);

  useEffect(() => {
    const savedTime = localStorage.getItem(`last_val_time_${estType}_${season}`);
    setLastValidationTime(savedTime || 'Never checked');
  }, [estType, season]);

  // Business States
  const [metrics, setMetrics] = useState({
    totalZones: 0,
    submittedZones: 0,
    pendingZones: 0,
    formPendingZones: 0,
    completedEstimations: 0,
    clarificationsPending: 0
  });

  const [currentStatus, setCurrentStatus] = useState('Validation Pending');
  const [loading, setLoading] = useState(false);
  const [validationResult, setValidationResult] = useState(null);
  
  // Modals / Drawers Controls
  const [openValidationFail, setOpenValidationFail] = useState(false);
  const [openInitiateConfirm, setOpenInitiateConfirm] = useState(false);
  
  // Running estimation simulation variables
  const [estimationProgress, setEstimationProgress] = useState(0);
  const [runningStep, setRunningStep] = useState(0); // 0: Idle, 1: Validation, 2: Calculation, 3: Completed

  // Load status & metrics whenever filters change
  useEffect(() => {
    fetchStatusAndMetrics();
    localStorage.setItem('earas_selected_estType', estType);
    localStorage.setItem('earas_selected_season', season);
  }, [estType, season]);

  const fetchStatusAndMetrics = () => {
    const s = areaEstimationService.getEstimationState(estType, year, season, district);
    setCurrentStatus(s);

    const m = areaEstimationService.getDashboardMetrics(estType, year, season, district);
    setMetrics(m);
  };

  // Run validation
  const handleValidate = () => {
    setLoading(true);
    setTimeout(() => {
      const result = areaEstimationService.validateForm1Submissions(estType, season, district);
      setValidationResult(result);
      setLoading(false);

      const timeStr = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
      localStorage.setItem(`last_val_time_${estType}_${season}`, timeStr);
      setLastValidationTime(timeStr);

      if (result.passed) {
        // Switch status to Ready to Initiate
        areaEstimationService.setEstimationState(estType, year, season, district, 'Ready to Initiate');
        setCurrentStatus('Ready to Initiate');
        setOpenInitiateConfirm(true);
      } else {
        areaEstimationService.setEstimationState(estType, year, season, district, 'Validation Pending');
        setCurrentStatus('Validation Pending');
        setOpenValidationFail(true);
        // Log validation fail notification
        areaEstimationService.addNotification({
          title: 'Validation Failed',
          message: `${estType} validation failed due to pending Form-1 submissions.`,
          type: 'error',
          timestamp: new Date().toISOString()
        });
      }
      fetchStatusAndMetrics();
    }, 1000);
  };



  // Initiate Estimation (simulates execution progress)
  const handleInitiate = async () => {
    setOpenInitiateConfirm(false);
    
    // API INTEGRATION POINT: Call the Axios service to trigger estimation on backend
    try {
      await areaEstimationService.apiInitiateEstimation({
        estType,
        year,
        season,
        districtId: district
      });
    } catch (err) {
      console.warn('Backend API call failed, proceeding with local mock simulation:', err);
    }

    areaEstimationService.initiateEstimation(estType, year, season, district);
    setCurrentStatus('Running');
    
    // Simulate background process
    setEstimationProgress(10);
    setRunningStep(1);
    
    const interval = setInterval(() => {
      setEstimationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setRunningStep(3);
          // Transition to Review Required
          setTimeout(() => {
            areaEstimationService.setEstimationState(estType, year, season, district, 'Review Required');
            setCurrentStatus('Review Required');
            setRunningStep(0);
            fetchStatusAndMetrics();
          }, 800);
          return 100;
        }
        
        // Progress steps
        const next = prev + 15;
        if (next >= 40 && next < 80) setRunningStep(2);
        return next;
      });
    }, 600);
  };

  const handleExportSummary = () => {
    const csvRows = [
      ['Metric', 'Value'],
      ['Estimation Type', estType],
      ['Year', year],
      ['Season', estType === 'Seasonal Crops' ? season : 'N/A'],
      ['Total Zones', metrics.totalZones],
      ['Submitted Zones', metrics.submittedZones],
      ['Form-1 Pending Zones', metrics.formPendingZones],
      ['Completed Estimations', metrics.completedEstimations],
      ['Clarifications Pending', metrics.clarificationsPending],
      ['Current Status', currentStatus]
    ];

    const csvContent = csvRows.map(e => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `Area_Estimation_Summary_${estType}_${year}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPending = () => {
    if (!validationResult || !validationResult.pendingZones) return;
    const csvRows = [
      ['District', 'Taluk', 'Zone', 'Investigator Name', 'Pending Clusters', 'Status'],
      ...validationResult.pendingZones.map(p => [
        p.district,
        p.taluk,
        p.zone,
        p.investigatorName || 'N/A',
        p.pendingClusters ? p.pendingClusters.join('; ') : '',
        'Pending Submission'
      ])
    ];
    const csvContent = csvRows.map(e => e.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `Pending_Form1_Submissions_${season}_${year}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed': return 'success';
      case 'Review Required': return 'warning';
      case 'Running': return 'info';
      case 'Ready to Initiate': return 'primary';
      default: return 'error';
    }
  };

  const getEstIcon = (type) => {
    switch (type) {
      case 'Land Utilization': return <LayersIcon sx={{ color: '#ffffff' }} />;
      case 'Irrigation': return <OpacityIcon sx={{ color: '#ffffff' }} />;
      case 'Seasonal Crops': return <SpaIcon sx={{ color: '#ffffff' }} />;
      default: return <GrainIcon sx={{ color: '#ffffff' }} />;
    }
  };

  return (
    <Grid container spacing={3}>
      <Breadcrumb />

      <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h3" fontWeight={700} sx={{ color: '#04255e' }}>
          Area Estimation Dashboard
        </Typography>
      </Grid>

      {/* Estimation Category Cards */}
      <Grid item xs={12}>
        <Grid container spacing={3}>
          {estimationCategories.map((card) => {
            const isSelected = estType === card.id;
            const stateForCard = areaEstimationService.getEstimationState(card.id, '2026', 'Autumn', 'All');
            return (
              <Grid item xs={12} sm={6} md={3} key={card.id}>
                <Card
                  onClick={() => setEstType(card.id)}
                  sx={{
                    borderRadius: 3,
                    cursor: 'pointer',
                    boxShadow: isSelected ? '0 10px 25px rgba(0,0,0,0.15)' : '0 4px 12px rgba(0,0,0,0.03)',
                    border: isSelected ? '2px solid #04255e' : '1px solid rgba(0,0,0,0.08)',
                    background: isSelected ? card.gradient : '#ffffff',
                    color: isSelected ? 'white' : 'text.primary',
                    transform: isSelected ? 'translateY(-6px)' : 'none',
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    '&:hover': {
                      transform: 'translateY(-6px)',
                      boxShadow: '0 12px 25px rgba(0,0,0,0.1)'
                    }
                  }}
                >
                  <CardContent sx={{ p: 2.5, display: 'flex', flexDirection: 'column', height: '100%', minHeight: 155, justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <Box>
                        <Typography variant="h5" fontWeight={700} sx={{ mb: 0.5, color: isSelected ? 'white' : '#04255e' }}>
                          {card.title}
                        </Typography>
                        <Typography variant="caption" sx={{ color: isSelected ? 'rgba(255,255,255,0.85)' : 'text.secondary' }}>
                          {card.desc}
                        </Typography>
                      </Box>
                      <Box sx={{
                        p: 1,
                        borderRadius: 2,
                        bgcolor: isSelected ? 'rgba(255,255,255,0.2)' : 'rgba(4, 37, 94, 0.08)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: isSelected ? 'white' : '#04255e'
                      }}>
                        {card.icon}
                      </Box>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
                      <Typography variant="caption" sx={{ color: isSelected ? 'rgba(255,255,255,0.7)' : 'text.secondary', fontWeight: 600 }}>
                        Status:
                      </Typography>
                      <Chip
                        label={stateForCard}
                        color={getStatusColor(stateForCard)}
                        size="small"
                        sx={{
                          fontWeight: 'bold',
                          color: 'white',
                          border: isSelected ? '1px solid white' : undefined
                        }}
                      />
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Grid>

      {/* Main Execution Workflow Panel */}
      <Grid item xs={12}>
        <MainCard
          title={
            <Stack direction="row" spacing={2} alignItems="center">
              {getEstIcon(estType)}
              <Typography variant="h4" fontWeight={600}>
                Estimation Execution Workflow
              </Typography>
            </Stack>
          }
          sx={{
            background: 'linear-gradient(135deg, #0f3460 0%, #16213e 100%)',
            color: 'white',
            '& .MuiTypography-root': { color: 'white' },
            borderRadius: 4,
            boxShadow: '0 12px 35px rgba(0,0,0,0.15)'
          }}
        >
          <Grid container spacing={3} alignItems="center">
            <Grid item xs={12} md={7}>
              <Typography variant="h5" sx={{ mb: 1, opacity: 0.9 }}>
                Active Target: <strong>{estType}</strong> {estType === 'Seasonal Crops' && `- ${season} Season`}
              </Typography>
              
              {/* Season select selector only for Seasonal Crops */}
              {estType === 'Seasonal Crops' && (
                <Box sx={{ mb: 2.5, display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>Select Season:</Typography>
                  <FormControl size="small" sx={{ minWidth: 150, bgcolor: 'white', borderRadius: 1.5 }}>
                    <Select
                      value={season}
                      onChange={(e) => setSeason(e.target.value)}
                      sx={{ color: '#04255e', fontWeight: 'bold' }}
                    >
                      <MenuItem value="Autumn">Autumn</MenuItem>
                      <MenuItem value="Winter">Winter</MenuItem>
                      <MenuItem value="Summer">Summer</MenuItem>
                    </Select>
                  </FormControl>
                </Box>
              )}

              <Typography variant="body1" sx={{ opacity: 0.8, mb: 3 }}>
                Before executing the estimation logic, validate that all reporting zones have successfully completed and uploaded their Form-1 datasets.
              </Typography>

              {/* Action buttons */}
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ gap: 2 }}>
                <Button
                  variant="contained"
                  disabled={loading || currentStatus === 'Running'}
                  onClick={handleValidate}
                  sx={{
                    bgcolor: '#2e7d32',
                    fontWeight: 'bold',
                    '&:hover': { bgcolor: '#1b5e20' },
                    borderRadius: 2,
                    px: 3,
                    py: 1
                  }}
                  startIcon={<CheckCircleOutlineIcon />}
                >
                  {loading ? 'Validating...' : 'Validate Data Availability'}
                </Button>

                <Button
                  variant="contained"
                  disabled={currentStatus !== 'Ready to Initiate' || currentStatus === 'Running'}
                  onClick={() => setOpenInitiateConfirm(true)}
                  sx={{
                    bgcolor: '#ff9800',
                    fontWeight: 'bold',
                    '&:hover': { bgcolor: '#f57c00' },
                    '&.Mui-disabled': { bgcolor: 'rgba(255, 152, 0, 0.3)', color: 'rgba(255,255,255,0.5)' },
                    borderRadius: 2,
                    px: 3,
                    py: 1
                  }}
                  startIcon={<PlayArrowIcon />}
                >
                  Initiate Estimation
                </Button>

                <Button
                  variant="outlined"
                  disabled={currentStatus !== 'Review Required' && currentStatus !== 'Completed'}
                  onClick={() => {
                    if (estType === 'Seasonal Crops') {
                      navigate('/schemes/earas/area-estimation/seasonal-results', { state: { estType, season } });
                    } else {
                      navigate('/schemes/earas/area-estimation/results', { state: { estType, season } });
                    }
                  }}
                  sx={{
                    borderColor: 'white',
                    color: 'white',
                    fontWeight: 'bold',
                    '&:hover': { borderColor: '#e0e0e0', bgcolor: 'rgba(255,255,255,0.08)' },
                    '&.Mui-disabled': { borderColor: 'rgba(255,255,255,0.2)', color: 'rgba(255,255,255,0.3)' },
                    borderRadius: 2,
                    px: 3,
                    py: 1
                  }}
                  startIcon={<TableChartIcon />}
                >
                  View Results
                </Button>

                <Button
                  variant="outlined"
                  onClick={handleExportSummary}
                  sx={{
                    borderColor: 'rgba(255,255,255,0.4)',
                    color: 'white',
                    fontWeight: 'bold',
                    '&:hover': { borderColor: 'white', bgcolor: 'rgba(255,255,255,0.08)' },
                    borderRadius: 2,
                    px: 2,
                    py: 1
                  }}
                  startIcon={<FileDownloadIcon />}
                >
                  Export Status
                </Button>
              </Stack>
            </Grid>

            {/* Status / Progress panel */}
            <Grid item xs={12} md={5}>
              <Box sx={{
                p: 3,
                borderRadius: 3,
                bgcolor: 'rgba(255,255,255,0.08)',
                border: '1px solid rgba(255,255,255,0.12)'
              }}>
                <Stack spacing={1.5}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="h6" color="inherit">Workflow Status</Typography>
                    <Chip
                      label={currentStatus}
                      color={getStatusColor(currentStatus)}
                      variant="filled"
                      sx={{ fontWeight: 'bold', borderRadius: 2 }}
                    />
                  </Box>
                  <Typography variant="caption" sx={{ display: 'block', opacity: 0.8, textAlign: 'right', fontStyle: 'italic' }}>
                    Last Validation Check: <strong>{lastValidationTime}</strong>
                  </Typography>

                  <Divider sx={{ borderColor: 'rgba(255,255,255,0.1)', my: 0.5 }} />

                  {/* Progressive tracker screen */}
                  {currentStatus === 'Running' ? (
                    <Box sx={{ pt: 1 }}>
                      <Typography variant="subtitle2" sx={{ mb: 1, color: '#ff9800' }}>
                        {runningStep === 1 && '🔍 Verifying datasets integrity...'}
                        {runningStep === 2 && '⚙️ Running agricultural extrapolation algorithms...'}
                        {runningStep === 3 && '✅ Compiling final tables...'}
                      </Typography>
                      <LinearProgress variant="determinate" value={estimationProgress} color="warning" sx={{ height: 8, borderRadius: 4, mb: 1 }} />
                      <Typography variant="caption" sx={{ display: 'block', textAlign: 'right', opacity: 0.8 }}>
                        {estimationProgress}% Completed
                      </Typography>
                    </Box>
                  ) : (
                    <Box sx={{ py: 1 }}>
                      {currentStatus === 'Validation Pending' && (
                        <Typography variant="body2" sx={{ color: '#ff8a80' }}>
                          ⚠️ Submissions are incomplete. Please trigger a Data Validation check to verify pending areas.
                        </Typography>
                      )}
                      {currentStatus === 'Ready to Initiate' && (
                        <Typography variant="body2" sx={{ color: '#a7ffeb' }}>
                          🎉 Form-1 submissions valid and complete. Click 'Initiate Estimation' to run calculations.
                        </Typography>
                      )}
                      {currentStatus === 'Review Required' && (
                        <Typography variant="body2" sx={{ color: '#ffd180' }}>
                          🔍 Estimation completed. Awaiting observation reviews and administrative approval.
                        </Typography>
                      )}
                      {currentStatus === 'Completed' && (
                        <Typography variant="body2" sx={{ color: '#b9f6ca' }}>
                          ✔️ Estimation successfully approved. Consolidated data ready for reporting.
                        </Typography>
                      )}
                    </Box>
                  )}
                </Stack>
              </Box>
            </Grid>
          </Grid>
        </MainCard>
      </Grid>

      {/* Validation Failure Drawer/Modal */}
      <Dialog
        open={openValidationFail}
        onClose={() => setOpenValidationFail(false)}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: { borderRadius: 3, p: 1 }
        }}
      >
        <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Stack direction="row" spacing={1} alignItems="center" sx={{ color: '#d32f2f' }}>
            <ErrorOutlineIcon />
            <Typography variant="h4" fontWeight={600} color="inherit">
              Pending Form-1 Submissions
            </Typography>
          </Stack>
          <IconButton onClick={() => setOpenValidationFail(false)}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers>
          <DialogContentText sx={{ mb: 2 }}>
            The following zones are pending Form-1 submissions for <strong>{season} Season ({year})</strong>. Validation failed. Estimation cannot be initiated.
          </DialogContentText>

          <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2, maxHeight: 350 }}>
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>District</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Taluk</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Zone</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Investigator</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Pending Clusters</TableCell>
                  <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {validationResult?.pendingZones?.length > 0 ? (
                  validationResult.pendingZones.map((row, idx) => (
                    <TableRow key={idx}>
                      <TableCell>{row.district}</TableCell>
                      <TableCell>{row.taluk}</TableCell>
                      <TableCell>{row.zone}</TableCell>
                      <TableCell>{row.investigatorName || 'N/A'}</TableCell>
                      <TableCell>
                        {row.pendingClusters && row.pendingClusters.length > 0 ? (
                          <Stack direction="row" spacing={0.5} useFlexGap flexWrap="wrap">
                            {row.pendingClusters.map((cluster, cidx) => (
                              <Chip key={cidx} label={cluster} size="small" variant="filled" sx={{ bgcolor: '#ffebee', color: '#c62828', fontWeight: 500 }} />
                            ))}
                          </Stack>
                        ) : (
                          'N/A'
                        )}
                      </TableCell>
                      <TableCell>
                        <Chip label={row.status} color="error" size="small" variant="outlined" sx={{ fontWeight: 'bold' }} />
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} align="center">No pending submissions found.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </DialogContent>
        <DialogActions sx={{ p: 2, display: 'flex', justifyContent: 'space-between' }}>
          <Button
            variant="outlined"
            onClick={handleExportPending}
            startIcon={<FileDownloadIcon />}
          >
            Export List
          </Button>
          <Button
            variant="outlined"
            onClick={handleValidate}
            startIcon={<RefreshIcon />}
          >
            Refresh
          </Button>
        </DialogActions>
      </Dialog>

      {/* Initiation Confirmation Dialog */}
      <Dialog
        open={openInitiateConfirm}
        onClose={() => setOpenInitiateConfirm(false)}
        PaperProps={{ sx: { borderRadius: 3, p: 1 } }}
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1, color: '#2e7d32' }}>
          <CheckCircleOutlineIcon />
          <Typography variant="h4" fontWeight={600} color="inherit">
            Confirm Estimation Initiation
          </Typography>
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            All required Form-1 submissions are available for <strong>{estType} ({year})</strong>. Do you want to proceed with executing the Area Estimation algorithm?
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button variant="outlined" color="secondary" onClick={() => setOpenInitiateConfirm(false)}>
            Cancel
          </Button>
          <Button variant="contained" color="success" onClick={handleInitiate} sx={{ bgcolor: '#2e7d32', '&:hover': { bgcolor: '#1b5e20' } }}>
            Initiate Estimation
          </Button>
        </DialogActions>
      </Dialog>

      
    </Grid>
  );
};

export default AreaEstimationDashboard;
