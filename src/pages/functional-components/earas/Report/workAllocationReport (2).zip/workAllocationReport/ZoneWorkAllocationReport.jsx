import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Grid,
  Typography,
  Box,
  Card,
  CardContent,
  Stack,
  Button,
  Alert,
  CircularProgress
} from '@mui/material';
import MainCard from 'components/MainCard';
import { useTheme } from '@mui/material/styles';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import Breadcrumb from 'routes/Breadcrumb';
import WorkAllocationTable from './WorkAllocationTable';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import LandscapeIcon from '@mui/icons-material/Landscape';
import LocationCityIcon from '@mui/icons-material/LocationCity';
import RefreshIcon from '@mui/icons-material/Refresh';
import { getCurrentUserJurisdiction, filterByJurisdiction, normalizeLocationData, fetchWorkAllocationApi } from './userJurisdiction';

function ZoneWorkAllocationReport() {
  const theme = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const { districtName: rawDistrictName, talukName: rawTalukName } = useParams();

  const districtName = decodeURIComponent(rawDistrictName || 'Thiruvananthapuram');
  const talukName = decodeURIComponent(rawTalukName || 'Neyyattinkara');

  const stateTalukId = location.state?.talukId || location.state?.talukData?.id;
  const stateDistrictId = location.state?.districtId || location.state?.districtData?.id;

  const [zoneList, setZoneList] = useState([]);
  const [summaryPlots, setSummaryPlots] = useState({ wet: 0, dry: 0, total: 0 });
  const [summaryArea, setSummaryArea] = useState({ wet: 0, dry: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const userJurisdiction = useMemo(() => getCurrentUserJurisdiction(), []);

  const resolveTalukId = useCallback(async (districtNameVal, talukNameVal) => {
    if (stateTalukId) return stateTalukId;

    try {
      let dId = stateDistrictId;
      if (!dId) {
        const stateRes = await fetchWorkAllocationApi('/api/report/work-allocation-progress');
        if (stateRes.ok) {
          const stateData = await stateRes.json();
          if (Array.isArray(stateData.locations)) {
            const foundD = stateData.locations.find(
              (d) => String(d.name).toLowerCase() === String(districtNameVal).toLowerCase()
            );
            if (foundD) dId = foundD.id;
          }
        }
      }

      if (!dId) return null;

      const talukRes = await fetchWorkAllocationApi(`/api/report/work-allocation-progress/${dId}`);
      if (talukRes.ok) {
        const talukData = await talukRes.json();
        if (Array.isArray(talukData.locations)) {
          const foundT = talukData.locations.find(
            (t) => String(t.name).toLowerCase() === String(talukNameVal).toLowerCase()
          );
          if (foundT) return foundT.id;
        }
      }
    } catch (e) {
      console.error('Error resolving taluk ID:', e);
    }
    return null;
  }, [stateTalukId, stateDistrictId]);

  const fetchZoneWorkAllocation = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const tId = await resolveTalukId(districtName, talukName);
      if (!tId) {
        throw new Error(`Could not resolve Taluk ID for "${talukName}".`);
      }

      const response = await fetchWorkAllocationApi(`/api/report/work-allocation-progress/taluk/${tId}`);

      if (!response.ok) {
        throw new Error(`Failed to fetch zone work allocation progress (${response.status})`);
      }

      const resData = await response.json();

      if (resData) {
        setSummaryPlots(resData.noOfPlots || { wet: 0, dry: 0, total: 0 });
        setSummaryArea(resData.areaAvailableForEstimation || { wet: 0, dry: 0, total: 0 });

        if (Array.isArray(resData.locations)) {
          const mapped = resData.locations.map((loc, idx) => normalizeLocationData(loc, idx));
          setZoneList(mapped);
        } else {
          setZoneList([]);
        }
      }
    } catch (err) {
      console.error('Error fetching Zone work allocation report:', err);
      setError(err.message || 'Error loading zone work allocation report data.');
    } finally {
      setLoading(false);
    }
  }, [districtName, talukName, resolveTalukId]);

  useEffect(() => {
    fetchZoneWorkAllocation();
  }, [fetchZoneWorkAllocation]);

  // Filter zone list if restricted by jurisdiction
  const visiblePanchayathList = filterByJurisdiction(
    zoneList,
    userJurisdiction.level,
    userJurisdiction.district,
    userJurisdiction.taluk
  );

  const totalPlotsWet = Number(summaryPlots.wet || visiblePanchayathList.reduce((sum, d) => sum + (d.plotsWet || 0), 0));
  const totalPlotsDry = Number(summaryPlots.dry || visiblePanchayathList.reduce((sum, d) => sum + (d.plotsDry || 0), 0));
  const totalPlotsTotal = Number(summaryPlots.total || (totalPlotsWet + totalPlotsDry));

  const totalAreaWet = Number(summaryArea.wet || visiblePanchayathList.reduce((sum, d) => sum + (d.availWetArea || 0), 0));
  const totalAreaDry = Number(summaryArea.dry || visiblePanchayathList.reduce((sum, d) => sum + (d.availDryArea || 0), 0));
  const totalAreaTotal = Number(summaryArea.total || (totalAreaWet + totalAreaDry));

  return (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Breadcrumb />
      </Grid>

      <Grid item xs={12}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1, flexWrap: 'wrap', gap: 2 }}>
          <Stack direction="row" spacing={2} alignItems="center">
            {/* Show Back to Taluk list if authorized */}
            {userJurisdiction.level !== 'taluk' && (
              <Button
                variant="outlined"
                startIcon={<ArrowBackIcon />}
                onClick={() => navigate(`/kerala_work_allocation_report/taluk/${encodeURIComponent(districtName)}`)}
                sx={{ textTransform: 'none', borderRadius: 2 }}
              >
                Back to {districtName} Taluks
              </Button>
            )}
            <Typography variant="h3" sx={{ fontWeight: 700, color: theme.palette.text.primary }}>
              {talukName} Taluk ({districtName} District) - Zone / Panchayat Report
            </Typography>
          </Stack>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={fetchZoneWorkAllocation}
            disabled={loading}
            sx={{ borderRadius: 2 }}
          >
            Refresh
          </Button>
        </Box>
      </Grid>

      {error && (
        <Grid item xs={12}>
          <Alert severity="error" onClose={() => setError(null)}>
            {error}
          </Alert>
        </Grid>
      )}

      {/* Compact Summary Cards */}
      <Grid item xs={12} md={6}>
        <Card sx={{ borderRadius: 2, border: '1px solid #e0e0e0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)', bgcolor: '#ffffff' }}>
          <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <LocationCityIcon sx={{ color: '#1976d2', mr: 0.8, fontSize: 20 }} />
              <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#333', fontSize: '0.95rem' }}>
                Number of Plots Available for Estimation
              </Typography>
            </Box>
            <Grid container spacing={1.5}>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e3f2fd', borderRadius: 1.5, border: '1px solid #bbdefb', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#0d47a1', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Wet
                  </Typography>
                  <Typography sx={{ color: '#0d47a1', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalPlotsWet.toLocaleString()}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#fff3e0', borderRadius: 1.5, border: '1px solid #ffe0b2', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#e65100', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Dry
                  </Typography>
                  <Typography sx={{ color: '#e65100', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalPlotsDry.toLocaleString()}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e8f5e9', borderRadius: 1.5, border: '1px solid #c8e6c9', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#1b5e20', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Total
                  </Typography>
                  <Typography sx={{ color: '#1b5e20', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalPlotsTotal.toLocaleString()}
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12} md={6}>
        <Card sx={{ borderRadius: 2, border: '1px solid #e0e0e0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)', bgcolor: '#ffffff' }}>
          <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <LandscapeIcon sx={{ color: '#2e7d32', mr: 0.8, fontSize: 20 }} />
              <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#333', fontSize: '0.95rem' }}>
                Area (in cents) Available for Estimation
              </Typography>
            </Box>
            <Grid container spacing={1.5}>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e3f2fd', borderRadius: 1.5, border: '1px solid #bbdefb', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#0d47a1', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Wet
                  </Typography>
                  <Typography sx={{ color: '#0d47a1', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalAreaWet.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#fff3e0', borderRadius: 1.5, border: '1px solid #ffe0b2', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#e65100', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Dry
                  </Typography>
                  <Typography sx={{ color: '#e65100', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalAreaDry.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e8f5e9', borderRadius: 1.5, border: '1px solid #c8e6c9', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#1b5e20', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Total
                  </Typography>
                  <Typography sx={{ color: '#1b5e20', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalAreaTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>

      {/* Main Table Card */}
      <Grid item xs={12}>
        <MainCard title={`Work Allocation Abstract - Panchayats / Municipalities of ${talukName} (${visiblePanchayathList.length} Zones)`}>
          <WorkAllocationTable
            data={visiblePanchayathList}
            locationColumnLabel="Panchayat / Municipality / Corporation"
            onDrillDown={null}
            loading={loading}
            searchTerm={searchTerm}
            onSearchChange={(e) => setSearchTerm(e.target.value)}
            showDrillDown={false}
            showBlockColumn={true}
            blockColumnLabel="Block"
            showZoneColumn={true}
            zoneColumnLabel="Zone Name"
            reportLevelName={`${talukName} Taluk (${districtName} District) Report (${userJurisdiction.role})`}
          />
        </MainCard>
      </Grid>
    </Grid>
  );
}

export default ZoneWorkAllocationReport;
