import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Grid,
  Typography,
  Box,
  Card,
  CardContent,
  Snackbar,
  Alert,
  Button,
  CircularProgress
} from '@mui/material';
import MainCard from 'components/MainCard';
import { useTheme } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';
import Breadcrumb from 'routes/Breadcrumb';
import WorkAllocationTable from './WorkAllocationTable';
import LandscapeIcon from '@mui/icons-material/Landscape';
import LocationCityIcon from '@mui/icons-material/LocationCity';
import RefreshIcon from '@mui/icons-material/Refresh';
import { getCurrentUserJurisdiction, normalizeLocationData, fetchWorkAllocationApi } from './userJurisdiction';

function KeralaWorkAllocationReport() {
  const theme = useTheme();
  const navigate = useNavigate();

  const [districtsData, setDistrictsData] = useState([]);
  const [summaryPlots, setSummaryPlots] = useState({ wet: 0, dry: 0, total: 0 });
  const [summaryArea, setSummaryArea] = useState({ wet: 0, dry: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [restrictionNotice, setRestrictionNotice] = useState('');

  const userJurisdiction = useMemo(() => getCurrentUserJurisdiction(), []);

  const fetchStateWorkAllocation = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetchWorkAllocationApi('/api/report/work-allocation-progress');

      if (!response.ok) {
        throw new Error(`Failed to fetch work allocation progress (${response.status})`);
      }

      const resData = await response.json();

      if (resData) {
        setSummaryPlots(resData.noOfPlots || { wet: 0, dry: 0, total: 0 });
        setSummaryArea(resData.areaAvailableForEstimation || { wet: 0, dry: 0, total: 0 });

        if (Array.isArray(resData.locations)) {
          const mapped = resData.locations.map((loc, idx) => normalizeLocationData(loc, idx));
          setDistrictsData(mapped);
        } else {
          setDistrictsData([]);
        }
      }
    } catch (err) {
      console.error('Error fetching Kerala work allocation report:', err);
      setError(err.message || 'Error loading work allocation report data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (userJurisdiction.level === 'taluk') {
      navigate(`/kerala_work_allocation_report/zone/${encodeURIComponent(userJurisdiction.district)}/${encodeURIComponent(userJurisdiction.taluk)}`, { replace: true });
      return;
    }
    fetchStateWorkAllocation();
  }, [userJurisdiction.level, userJurisdiction.district, userJurisdiction.taluk, navigate, fetchStateWorkAllocation]);

  const handleDrillDownToTaluk = (districtRow) => {
    const districtName = districtRow.name || districtRow.district;
    const districtId = districtRow.id;

    if (userJurisdiction.level === 'district' && districtName.toLowerCase() !== userJurisdiction.district.toLowerCase()) {
      setRestrictionNotice(`Access Restricted: You are assigned to ${userJurisdiction.district} District.`);
      return;
    }

    navigate(`/kerala_work_allocation_report/taluk/${encodeURIComponent(districtName)}`, {
      state: { districtId, districtName, districtData: districtRow }
    });
  };

  const visibleDistricts = districtsData;

  const totalPlotsWet = Number(summaryPlots.wet || visibleDistricts.reduce((sum, d) => sum + (d.plotsWet || 0), 0));
  const totalPlotsDry = Number(summaryPlots.dry || visibleDistricts.reduce((sum, d) => sum + (d.plotsDry || 0), 0));
  const totalPlotsTotal = Number(summaryPlots.total || (totalPlotsWet + totalPlotsDry));

  const totalAreaWet = Number(summaryArea.wet || visibleDistricts.reduce((sum, d) => sum + (d.availWetArea || 0), 0));
  const totalAreaDry = Number(summaryArea.dry || visibleDistricts.reduce((sum, d) => sum + (d.availDryArea || 0), 0));
  const totalAreaTotal = Number(summaryArea.total || (totalAreaWet + totalAreaDry));

  return (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Breadcrumb />
      </Grid>

      {/* Header */}
      <Grid item xs={12}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1, flexWrap: 'wrap', gap: 2 }}>
          <Typography variant="h3" sx={{ fontWeight: 700, color: theme.palette.text.primary }}>
            Work Allocation Abstract Report - Kerala State
          </Typography>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={fetchStateWorkAllocation}
            disabled={loading}
            sx={{ borderRadius: 2 }}
          >
            Refresh
          </Button>
        </Box>
      </Grid>

      {error && (
        <Grid item xs={12}>
          <Alert severity="error" onClose={() => setError(null)}>
            {error}
          </Alert>
        </Grid>
      )}

      {/* Compact Summary Cards */}
      <Grid item xs={12} md={6}>
        <Card sx={{ borderRadius: 2, border: '1px solid #e0e0e0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)', bgcolor: '#ffffff' }}>
          <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <LocationCityIcon sx={{ color: '#1976d2', mr: 0.8, fontSize: 20 }} />
              <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#333', fontSize: '0.95rem' }}>
                Number of Plots Available for Estimation
              </Typography>
            </Box>
            <Grid container spacing={1.5}>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e3f2fd', borderRadius: 1.5, border: '1px solid #bbdefb', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#0d47a1', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Wet
                  </Typography>
                  <Typography sx={{ color: '#0d47a1', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalPlotsWet.toLocaleString()}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#fff3e0', borderRadius: 1.5, border: '1px solid #ffe0b2', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#e65100', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Dry
                  </Typography>
                  <Typography sx={{ color: '#e65100', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalPlotsDry.toLocaleString()}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e8f5e9', borderRadius: 1.5, border: '1px solid #c8e6c9', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#1b5e20', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Total
                  </Typography>
                  <Typography sx={{ color: '#1b5e20', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalPlotsTotal.toLocaleString()}
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>

      <Grid item xs={12} md={6}>
        <Card sx={{ borderRadius: 2, border: '1px solid #e0e0e0', boxShadow: '0 2px 8px rgba(0,0,0,0.04)', bgcolor: '#ffffff' }}>
          <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <LandscapeIcon sx={{ color: '#2e7d32', mr: 0.8, fontSize: 20 }} />
              <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#333', fontSize: '0.95rem' }}>
                Area (in cents) Available for Estimation
              </Typography>
            </Box>
            <Grid container spacing={1.5}>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e3f2fd', borderRadius: 1.5, border: '1px solid #bbdefb', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#0d47a1', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Wet
                  </Typography>
                  <Typography sx={{ color: '#0d47a1', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalAreaWet.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#fff3e0', borderRadius: 1.5, border: '1px solid #ffe0b2', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#e65100', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Dry
                  </Typography>
                  <Typography sx={{ color: '#e65100', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalAreaDry.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={4}>
                <Box sx={{ py: 0.8, px: 1, bgcolor: '#e8f5e9', borderRadius: 1.5, border: '1px solid #c8e6c9', textAlign: 'center' }}>
                  <Typography variant="caption" sx={{ color: '#1b5e20', fontWeight: 700, fontSize: '0.7rem', textTransform: 'uppercase', display: 'block' }}>
                    Total
                  </Typography>
                  <Typography sx={{ color: '#1b5e20', fontWeight: 800, fontSize: '1.05rem', lineHeight: 1.2, mt: 0.3 }}>
                    {loading ? <CircularProgress size={16} /> : totalAreaTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Grid>

      {/* Main Table Card */}
      <Grid item xs={12}>
        <MainCard title={`Work Allocation Abstract - District Wise Report (${visibleDistricts.length} Districts)`}>
          <WorkAllocationTable
            data={visibleDistricts}
            locationColumnLabel="District Name"
            onDrillDown={handleDrillDownToTaluk}
            loading={loading}
            searchTerm={searchTerm}
            onSearchChange={(e) => setSearchTerm(e.target.value)}
            showDrillDown={true}
            reportLevelName={`Kerala State Report (${userJurisdiction.role})`}
          />
        </MainCard>
      </Grid>

      {/* Access Restriction Notification Toast */}
      <Snackbar
        open={Boolean(restrictionNotice)}
        autoHideDuration={4000}
        onClose={() => setRestrictionNotice('')}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setRestrictionNotice('')} severity="warning" variant="filled" sx={{ width: '100%', fontWeight: 600 }}>
          {restrictionNotice}
        </Alert>
      </Snackbar>
    </Grid>
  );
}

export default KeralaWorkAllocationReport;
